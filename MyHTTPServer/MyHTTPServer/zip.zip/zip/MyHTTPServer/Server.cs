﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using MyHTTPServer.configuration;

namespace MyHTTPServer
{
    public class Server
    {
        private static readonly string configPath = @"configuration/appsetting.json";

        private HttpListener _listener;
        private ServerConfig _serverConfig;
        private static bool _isStop = true; 
        private static CancellationTokenSource _cts;

        public Server()
        {
            _serverConfig = new ServerConfig(configPath);
            _listener = new HttpListener();
            _listener.Prefixes.Add($"{_serverConfig.configInfo.Address}:{_serverConfig.configInfo.Port}/");
            _cts = new CancellationTokenSource();
        }

        public async Task Start()
        {
            _isStop = false;
            var serverListeningTask = Task.Run( async () => await StartServerListening(_cts.Token), _cts.Token);
            while (!_isStop)
                _isStop = await IsStop();

            _cts.Cancel();

            if (_listener.IsListening)
            {
                await Console.Out.WriteLineAsync("Сервер остановлен");
                _listener.Stop();
            }
            await Console.Out.WriteLineAsync("Работа сервера завершена");
        }

        async private Task StartServerListening(CancellationToken _token)
        {
            if (_listener.Prefixes.Count == 0)
                throw new ArgumentException("Server has no prefixes");

            try
            {  
                _listener.Start();
                await Console.Out.WriteLineAsync("Сервер запущен");
                var staticFilesHandler = new StaticFilesHandler(_serverConfig);
                var emailSender = new EmailSenderService();

                while (!_token.IsCancellationRequested)
                {
                    var context = await _listener.GetContextAsync();
                    if (context.Request.HttpMethod.ToLower().Equals("get"))
                        await staticFilesHandler.Handle(context);
                    else if (context.Request.HttpMethod.ToLower().Equals("post"))
                    {
                        string message = CreateEmailFormMessage(context.Request).Result;
                        await emailSender.SendEmailAsync("1chessmic@gmail.com", "test", message);
                        context.Response.Redirect(_listener.Prefixes.First());
                        context.Response.Close();
                        await Task.Delay(1000);
                    }
                }
            }
            catch (Exception ex) { await Console.Out.WriteLineAsync(ex.Message); }
        }

        private async Task SendResponseAsync(HttpListenerContext context)
        {
            var response = context.Response;
            var request = string.Join("", context.Request.RawUrl.Skip(1).ToArray());

            await ShowRequestData(context.Request);

            var path = $@"..\..\..\{_serverConfig.configInfo.StaticFilesPath}\index.html";

            byte[] responseBuffer;

            if (request.StartsWith("imgs") || request.StartsWith("styles"))
                responseBuffer = File.ReadAllBytes($@"../../../{_serverConfig.configInfo.StaticFilesPath}/{request}");
            else if (context.Request.HttpMethod.ToLower().Equals("post"))
            {
                var emailSender = new EmailSenderService();
                await emailSender.SendEmailAsync("1chessmic@gmail.com", "subj", "hello");
               await Console.Out.WriteLineAsync(request);
               responseBuffer = File.ReadAllBytes(File.Exists(path) ? path : "<h4>404 - Not Found</h4>");
            }
            else
                responseBuffer = File.ReadAllBytes(File.Exists(path) ? path : "<h4>404 - Not Found</h4>");

            response.ContentLength64 = responseBuffer.Length;
            using Stream output = response.OutputStream;
            if (responseBuffer != null)
            {
                await output.WriteAsync(responseBuffer);
                await output.FlushAsync();
            }
            output.Close();

            await Console.Out.WriteLineAsync("Запрос обработан");
        }

        private async Task<bool> IsStop() =>  Console.ReadLine().ToLower().Equals("stop");

        private async Task ShowRequestData(HttpListenerRequest request)
        {
            if (!request.HasEntityBody)
            {
                //Console.WriteLine("No client data was sent with the request.");
                return;
            }
            System.IO.Stream body = request.InputStream;
            System.Text.Encoding encoding = request.ContentEncoding; 
            System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
            if (request.ContentType != null)
            {
                Console.WriteLine("Client data content type {0}", request.ContentType);
            }
            Console.WriteLine("Client data content length {0}", request.ContentLength64);

            Console.WriteLine("Start of client data:");
            // Convert the data to a string and display it on the console.
            string s = reader.ReadToEnd();
            Console.WriteLine(s);
            Console.WriteLine("End of client data:");
            body.Close();
            reader.Close();
            // If you are finished with the request, it should be closed also.
        }

        private async Task<string> CreateEmailFormMessage(HttpListenerRequest request)
        {
            if (!request.HasEntityBody)
            {
                return default(string);
            }

            var stream = new StreamReader(request.InputStream);
            var str = await stream.ReadToEndAsync();
            str = Uri.UnescapeDataString(Regex.Unescape(str));
            str = str.Replace("&", "\n");
            str = str.Replace("=", ": ");
            str = str.Replace("+", " ");

            return str;
        }
    }
}
